# project-geeks

## INSTRUCTIONS TO OPERATE

### HOW TO VIEW THE WEBSITE

In order to view the website please run the following commmand
```python3 app.py``` after navigating to the src folder and follow the link that is being displayed on the terminal. 

### STRUCTURE OF FILES

Our repository contains an src folder having app.py and two folders namely static and templates which contains all the HTML,CSS and Javascript files required for the website to run smoothly for the website.

### THE NAVIGATION BAR AND THE FOOTER
 
All the pages consists of the navigation bar and the footer.
The navigation bar consists of the links required to redirect to the artists page,the about page and the home page.
The footer consists of the links to the same as mentioned in the navigation bar along with that it consists of the links to the social media platform and the contact details.

### THE STRUCTURE OF THE WEBSITE

There are a total of 5 artists that we have included in the website and each artist have 5 albums where each album is having 5-6 songs. All these are connected as required and expected. Other than that, the website consists of search page, spotlight page and the playlist page too which serves the required purposes.
